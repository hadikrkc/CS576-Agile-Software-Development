﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SPLEModelUpdateTool.Tests
{
    [TestClass]
    //FileProcess Classın test edildiği class
    public class FileProcessTest
    {
        [TestMethod]
       
        public void Test_readFeature()
        {
            //Arrange

            //Act

            //Assert
        }
    }
}

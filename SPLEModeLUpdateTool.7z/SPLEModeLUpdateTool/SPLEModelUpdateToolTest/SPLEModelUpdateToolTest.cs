﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SPLEModelUpdateToolTest
{
    [TestClass]
    public class SPLEModelUpdateToolTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            

        }
    }
}
